# Point-Cloud Routes

**Point-Cloud Routes** is a Python library designed to reconstruct and discover sequential routes from unorganized spatial point clouds. 

The algorithm utilizes an iterative approach based on **local density**, **inverse-proximity scoring**, and vectorized **angular/directional constraints** via NumPy. It is ideal for processing GPS tracking data, sensor trajectories, and noisy geospatial datasets.

---

## Installation

### Local Installation 
```bash
pip install link
```

---

## Quick Start

```python
import pandas as pd
from pointcloudroutes import discover_route

# 1. Prepare your geospatial data
data = {
    'lon': [-46.6333, -46.6340, -46.6350, -46.6360],
    'lat': [-23.5505, -23.5510, -23.5515, -23.5520],
    'speed': [45.0, 48.2, 50.1, 42.5]
}
df = pd.DataFrame(data)

# 2. Define the starting point [longitude, latitude]
initial_point = [-46.6333, -23.5505]

# 3. Run the routing algorithm
route_df = discover_route(
    df=df,
    initial_point=initial_point,
    meters=5,                # Initial search radius in meters
    iterations=100,          # Maximum routing steps
    to_maintain=['speed']    # Columns to aggregate by mean
)

print(route_df.head())
```

---

## How the Algorithm Works

At each step, the algorithm executes the following sequence:

1. **Candidate Generation:** Generates a circular ring of `angular_samples` (default: 64) candidate points around the current position based on the current search radius (`meters`).
2. **Angular Filtering:** Once a heading is established (at least 2 route points), it computes the dot product between the route heading vector and the dataset point delta vectors. Only points with a cosine similarity greater than zero (curves under 90 degrees) are evaluated.
3. **Density Scoring:** Scores each candidate point using an inverse-distance formula against active dataset clusters:
   $$\text{Score} = \sum \left( \frac{1}{\text{current distance}} \times \frac{1}{\text{candidate distance}} \right)$$
4. **Adaptive Step Adjustments:** The highest-scoring candidate becomes the next route node. If no dense point clusters are found, the search radius scales up by `increase_meters`. Upon success, it shrinks by `decrease_meters` to keep the path tight.

---

## Function Reference

```python
discover_route(
    df: pd.DataFrame, 
    initial_point: list[float, float], 
    meters: int = 5, 
    lon_col: str = "lon", 
    lat_col: str = "lat",
    angular_samples: int = 64, 
    iterations: int = 300, 
    increase_meters: float = 1.5, 
    decrease_meters: float = 0.67, 
    max_meters: float = 100, 
    to_maintain: list = [],
    verbose: bool = False
) -> pd.DataFrame
```

### Main Parameters:
- `df`: Input DataFrame containing spatial coordinates.
- `initial_point`: Starting coordinate as a `[longitude, latitude]` list.
- `meters`: Initial search radius step in meters.
- `increase_meters` / `decrease_meters`: Search radius scaling multipliers.
- `to_maintain`: Numerical columns from `df` to average out and attach to the route path.

